Processing Video
================

Repository of the video library for Processing. 

This library comprises classes for movie playback and video capture. It is based on the [gstreamer multimedia framework](http://gstreamer.freedesktop.org/), and uses the [gstreamer-java](https://code.google.com/p/gstreamer-java/) bindings to interface gstreamer from Java.

Please submit all your bug reports and pull requests related to the video library here. Your contribution is really important to keep the Processing project moving forward!

Andres Colubri

5 June 2014
